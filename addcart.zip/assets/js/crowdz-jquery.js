/*------------------------------------------jquery from index-user page----------------------------------------------------*/
$(document).ready(function(){
      $(".listing").hide();
	  $(".orders").hide();
	  $(".promot").hide();
	  $(".finance").hide();
	  $(".shop-setting").hide();
	  $(".edu-support").hide();
});

$(document).ready(function(){
    $(".myshop-col-ele1").mouseover(function(){
        $(".quick-link").show();
        $(".listing").hide();
		  $(".orders").hide();
		  $(".promot").hide();
		  $(".finance").hide();
		  $(".shop-setting").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele2").mouseover(function(){
        $(".listing").show();
		 $(".quick-link").hide();
		  $(".orders").hide();
		  $(".promot").hide();
		  $(".finance").hide();
		  $(".shop-setting").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele3").mouseover(function(){
	$(".orders").show();
        $(".listing").hide();
		 $(".quick-link").hide();
		  $(".promot").hide();
		  $(".finance").hide();
		  $(".shop-setting").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele4").mouseover(function(){
	$(".promot").show();
	$(".orders").hide();
        $(".listing").hide();
		 $(".quick-link").hide();
		  $(".finance").hide();
		  $(".shop-setting").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele5").mouseover(function(){
	 $(".finance").show();
	$(".promot").hide();
	$(".orders").hide();
        $(".listing").hide();
		 $(".quick-link").hide();
		 
		  $(".shop-setting").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele7").mouseover(function(){
	$(".shop-setting").show();
	 $(".finance").hide();
	$(".promot").hide();
	$(".orders").hide();
        $(".listing").hide();
		 $(".quick-link").hide();
		  $(".edu-support").hide();
    });
});

$(document).ready(function(){
    $(".myshop-col-ele8").mouseover(function(){
	 $(".edu-support").show();
	$(".shop-setting").hide();
	 $(".finance").hide();
	$(".promot").hide();
	$(".orders").hide();
        $(".listing").hide();
		 $(".quick-link").hide();
    });
});

$(window).scroll(function() {

    if ($(this).scrollTop()>0)
     {
        $('.sub-menu').fadeOut();
     }
    else
     {
      $('.sub-menu').fadeIn();
     }
 });
 
 
 /*----------------------------sub menu script-------------------------------------*/
 $(document).ready(function(){
      $(".ele2-data").hide();
      $(".ele3-data").hide();
      $(".ele4-data").hide();
	  $(".ele5-data").hide();$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
		
	$(".sub-item").hide();
});


$(document).ready(function(){
    $(".ele1").mouseover(function(){
	$(".ele1-data").show();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
        $(".ele4-data").hide();
		$(".ele5-data").hide();$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});
$(document).ready(function(){
    $(".ele2").mouseover(function(){
	$(".ele2-data").show();
        $(".ele1-data").hide();
        $(".ele3-data").hide();
        $(".ele4-data").hide();
		$(".ele5-data").hide();$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});
$(document).ready(function(){
    $(".ele3").mouseover(function(){
	$(".ele3-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele4-data").hide();
		$(".ele5-data").hide();
		$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});


$(document).ready(function(){
    $(".ele4").mouseover(function(){
	$(".ele4-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
		$(".ele5-data").hide();
		$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});

$(document).ready(function(){
    $(".ele5").mouseover(function(){
	$(".ele5-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
		$(".ele4-data").hide();
		$(".ele6-data").hide();$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});

$(document).ready(function(){
    $(".ele6").mouseover(function(){
	$(".ele6-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
		$(".ele4-data").hide();
		$(".ele5-data").hide();
		$(".ele7-data").hide();
		$(".ele8-data").hide();
    });
});

$(document).ready(function(){
    $(".ele7").mouseover(function(){
	$(".ele7-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
		$(".ele4-data").hide();
		$(".ele5-data").hide();
		$(".ele6-data").hide();
		$(".ele8-data").hide();
    });
});

$(document).ready(function(){
    $(".ele8").mouseover(function(){
	$(".ele8-data").show();
        $(".ele1-data").hide();
        $(".ele2-data").hide();
        $(".ele3-data").hide();
		$(".ele4-data").hide();
		$(".ele5-data").hide();
		$(".ele6-data").hide();
		$(".ele7-data").hide();
    });
});

$(document).ready(function(){
	
    $(".item-header").mouseover(function(){
		var div = $(this).next('.sub-item');
		div.show(500);
    });
});
/*-------------------sub menu script for responsive-----------------------*/

 $(document).ready(function(){
    $(".main-product-name1").hide();
    $(".main-product-name2").hide();
    $(".main-product-name3").hide();
    $(".main-product-name4").hide();
    $(".main-product-name5").hide();
    $(".main-product-name6").hide();
});

$(document).ready(function(){
    $(".main-product-tag1").click(function(){
        
        if($(".main-product-name1").is(":hidden") ){
                $(".main-product-name1").show(500);
        }	
        else if($(".main-product-name1").is(":visible")){
                $(".main-product-name1").hide(500);
        }						
                    
                    
        $(".main-product-name2").hide();
        $(".main-product-name3").hide();
        $(".main-product-name4").hide();
		$(".main-product-name5").hide();
		$(".main-product-name6").hide();
    });
});

$(document).ready(function(){
    $(".main-product-tag2").click(function(){
	
        if($(".main-product-name2").is(":hidden") ){
                $(".main-product-name2").show(500);
        }	
        else if($(".main-product-name2").is(":visible")){
                $(".main-product-name2").hide(500);
        }	
        $(".main-product-name1").hide();
        $(".main-product-name3").hide();
        $(".main-product-name4").hide();
		$(".main-product-name5").hide();
		$(".main-product-name6").hide();
    });
});

$(document).ready(function(){
    $(".main-product-tag3").click(function(){
	if($(".main-product-name3").is(":hidden") ){
                $(".main-product-name3").show(500);
        }	
        else if($(".main-product-name3").is(":visible")){
                $(".main-product-name3").hide(500);
        }	
        $(".main-product-name2").hide();
        $(".main-product-name1").hide();
        $(".main-product-name4").hide();
		$(".main-product-name5").hide();
		$(".main-product-name6").hide();
    });
});

$(document).ready(function(){
    $(".main-product-tag4").click(function(){
	if($(".main-product-name4").is(":hidden") ){
                $(".main-product-name4").show(500);
        }	
        else if($(".main-product-name4").is(":visible")){
                $(".main-product-name4").hide(500);
        }	
        $(".main-product-name2").hide();
        $(".main-product-name3").hide();
        $(".main-product-name1").hide();
		$(".main-product-name5").hide();
		$(".main-product-name6").hide();
    });
});

$(document).ready(function(){
    $(".main-product-tag5").click(function(){
	if($(".main-product-name5").is(":hidden") ){
                $(".main-product-name5").show(500);
        }	
        else if($(".main-product-name5").is(":visible")){
                $(".main-product-name5").hide(500);
        }	
        $(".main-product-name2").hide();
        $(".main-product-name3").hide();
        $(".main-product-name4").hide();
		$(".main-product-name1").hide();
		$(".main-product-name6").hide();
    });
});

$(document).ready(function(){
    $(".main-product-tag6").click(function(){
	if($(".main-product-name6").is(":hidden") ){
                $(".main-product-name6").show(500);
        }	
        else if($(".main-product-name6").is(":visible")){
                $(".main-product-name6").hide(500);
        }
        $(".main-product-name2").hide();
        $(".main-product-name3").hide();
        $(".main-product-name4").hide();
		$(".main-product-name5").hide();
		$(".main-product-name1").hide();
    });
});


$(document).ready(function(){
     var width = $(window).width();
    if (width < 768) {
        $("#sub-menu-responsive").show();
    }
    else {
       $("#sub-menu-responsive").hide();
    }
});
/*------------------------------------------jquery from index-user page----------------------------------------------------*/